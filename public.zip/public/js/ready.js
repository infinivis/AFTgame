$(document).ready(function () {
    
    console.log("ready!");
    





   

    




});/////end DOM ready