var NOEUD = function (){
			this.x=0;
			this.y=0;
//			this.x=0;
//			this.y=0;
			this.length=0;
			this.parent = null;
			this.left = null;
			this.right = null;
                        this.feuille = null;
                        this.abricot = null;
                        this.fleurs = null;
                        this.isGrandFather = null;
                        
			
		}