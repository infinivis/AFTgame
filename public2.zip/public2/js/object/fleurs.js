var FLEURS = function (){
			this.x=0;
			this.y=0;
			this.size=0;
			this.momx=0;
			this.momy=0;
			this.accroche=true;
			this.dureeVie=0;
		}