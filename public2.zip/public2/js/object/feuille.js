var FEUILLE = function (){
			this.x=0;
			this.y=0;
			this.size=0;
			this.momx=0;
			this.momy=0;
			this.accroche=true;
			this.color='#175732';
			this.borderColor='#000000';
			this.dureeVie=0;
		}