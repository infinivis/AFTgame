//globals for infos Screen
var pressionG =0;

var humiditeG=0;

var tempG = localStorage.getItem("temp");

var nbAbricotsSemaineG=0;

var nbAbricotsJourG=0;

var nbAbricotsCourantG=0;

var nbPartieG=0;

var timeG = localStorage.getItem("time");

var warningG=0;

var lkmInstantG=0;

var lkmPicG=0;

var lkmMoyG=0;

var rkmInstantG=0;

var rkmPicG=0;

var rkmMoyG=0;

var ecartNoG=0;

var jaugeLeft = 0; 
var jaugeRight = 0; 
var jaugeMiddle = 0; 



