//lédGauche
var led1 = function(ctx){
        
      ctx.beginPath();
      ctx.moveTo(220.7, 267.7);
      ctx.lineTo(216.4, 267.7);
      ctx.lineTo(216.4, 242.7);
      ctx.lineTo(220.7, 242.7);
      ctx.lineTo(220.7, 267.7);
      ctx.closePath();
      ctx.fill(); 
     }
     var led2 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(226.7, 267.9);
      ctx.lineTo(222.3, 267.7);
      ctx.lineTo(223.6, 242.7);
      ctx.lineTo(228.0, 242.9);
      ctx.lineTo(226.7, 267.9);
      ctx.closePath();
      ctx.fill();
      }
var led3 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(232.6, 268.5);
      ctx.lineTo(228.3, 268.1);
      ctx.lineTo(230.9, 243.2);
      ctx.lineTo(235.2, 243.6);
      ctx.lineTo(232.6, 268.5);
      ctx.closePath();
      ctx.fill();
      }
var led4 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(238.5, 269.4);
      ctx.lineTo(234.2, 268.7);
      ctx.lineTo(238.1, 244.0);
      ctx.lineTo(242.4, 244.7);
      ctx.lineTo(238.5, 269.4);
      ctx.closePath();
      ctx.fill();
      }
var led5 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(244.4, 270.6);
      ctx.lineTo(240.1, 269.7);
      ctx.lineTo(245.3, 245.2);
      ctx.lineTo(249.6, 246.1);
      ctx.lineTo(244.4, 270.6);
      ctx.closePath();
      ctx.fill();
      }
var led6 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(250.1, 272.1);
      ctx.lineTo(246.0, 271.0);
      ctx.lineTo(252.4, 246.8);
      ctx.lineTo(256.6, 247.9);
      ctx.lineTo(250.1, 272.1);
      ctx.closePath();
      ctx.fill();
      }
var led7 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(255.8, 273.9);
      ctx.lineTo(251.7, 272.6);
      ctx.lineTo(259.4, 248.7);
      ctx.lineTo(263.6, 250.1);
      ctx.lineTo(255.8, 273.9);
      ctx.closePath();
      ctx.fill();
      }
var led8 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(261.4, 276.0);
      ctx.lineTo(257.4, 274.5);
      ctx.lineTo(266.3, 251.1);
      ctx.lineTo(270.4, 252.6);
      ctx.lineTo(261.4, 276.0);
      ctx.closePath();
      ctx.fill();
      }
var led9 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(266.9, 278.4);
      ctx.lineTo(262.9, 276.7);
      ctx.lineTo(273.1, 253.7);
      ctx.lineTo(277.1, 255.5);
      ctx.lineTo(266.9, 278.4);
      ctx.closePath();
      ctx.fill();
      }
var led10 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(272.2, 281.1);
      ctx.lineTo(268.4, 279.1);
      ctx.lineTo(279.7, 256.8);
      ctx.lineTo(283.6, 258.7);
      ctx.lineTo(272.2, 281.1);
      ctx.closePath();
      ctx.fill();
      }
var led11 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(277.4, 284.0);
      ctx.lineTo(273.7, 281.9);
      ctx.lineTo(286.2, 260.1);
      ctx.lineTo(289.9, 262.3);
      ctx.lineTo(277.4, 284.0);
      ctx.closePath();
      ctx.fill();
      }
var led12 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(282.5, 287.2);
      ctx.lineTo(278.8, 284.9);
      ctx.lineTo(292.5, 263.8);
      ctx.lineTo(296.1, 266.2);
      ctx.lineTo(282.5, 287.2);
      ctx.closePath();
      ctx.fill();
      }
var led13 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(287.3, 290.7);
      ctx.lineTo(283.8, 288.2);
      ctx.lineTo(298.5, 267.9);
      ctx.lineTo(302.0, 270.4);
      ctx.lineTo(287.3, 290.7);
      ctx.closePath();
      ctx.fill();
      }
var led14 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(292.0, 294.4);
      ctx.lineTo(288.6, 291.7);
      ctx.lineTo(304.4, 272.2);
      ctx.lineTo(307.7, 274.9);
      ctx.lineTo(292.0, 294.4);
      ctx.closePath();
      ctx.fill();
      }
var led15 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(296.5, 298.4);
      ctx.lineTo(293.2, 295.5);
      ctx.lineTo(310.0, 276.8);
      ctx.lineTo(313.2, 279.7);
      ctx.lineTo(296.5, 298.4);
      ctx.closePath();
      ctx.fill();
      }
var led16 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(300.7, 302.6);
      ctx.lineTo(297.6, 299.5);
      ctx.lineTo(315.4, 281.8);
      ctx.lineTo(318.4, 284.8);
      ctx.lineTo(300.7, 302.6);
      ctx.closePath();
      ctx.fill();
      }
var led17 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(304.7, 307.0);
      ctx.lineTo(301.8, 303.8);
      ctx.lineTo(320.5, 287.0);
      ctx.lineTo(323.4, 290.2);
      ctx.lineTo(304.7, 307.0);
      ctx.closePath();
      ctx.fill();
      }
var led18 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(308.5, 311.6);
      ctx.lineTo(305.8, 308.2);
      ctx.lineTo(325.3, 292.4);
      ctx.lineTo(328.0, 295.8);
      ctx.lineTo(308.5, 311.6);
      ctx.closePath();
      ctx.fill();
}
var led19 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(312.1, 316.4);
      ctx.lineTo(309.5, 312.9);
      ctx.lineTo(329.8, 298.1);
      ctx.lineTo(332.4, 301.6);
      ctx.lineTo(312.1, 316.4);
      ctx.closePath();
      ctx.fill();
}
var led20 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(315.4, 321.4);
      ctx.lineTo(313.0, 317.7);
      ctx.lineTo(334.0, 304.1);
      ctx.lineTo(336.4, 307.7);
      ctx.lineTo(315.4, 321.4);
      ctx.closePath();
      ctx.fill();
}
var led21 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(318.4, 326.5);
      ctx.lineTo(316.2, 322.8);
      ctx.lineTo(337.9, 310.2);
      ctx.lineTo(340.1, 314.0);
      ctx.lineTo(318.4, 326.5);
      ctx.closePath();
      ctx.fill();
}
var led22 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(321.1, 331.8);
      ctx.lineTo(319.2, 328.0);
      ctx.lineTo(341.5, 316.6);
      ctx.lineTo(343.5, 320.4);
      ctx.lineTo(321.1, 331.8);
      ctx.closePath();
      ctx.fill();
}
var led23 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(323.6, 337.2);
      ctx.lineTo(321.8, 333.3);
      ctx.lineTo(344.7, 323.1);
      ctx.lineTo(346.5, 327.0);
      ctx.lineTo(323.6, 337.2);
      ctx.closePath();
      ctx.fill();
}
var led24 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(325.8, 342.8);
      ctx.lineTo(324.2, 338.8);
      ctx.lineTo(347.6, 329.8);
      ctx.lineTo(349.2, 333.8);
      ctx.lineTo(325.8, 342.8);
      ctx.closePath();
      ctx.fill();
}
var led25 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(327.7, 348.4);
      ctx.lineTo(326.3, 344.3);
      ctx.lineTo(350.2, 336.6);
      ctx.lineTo(351.5, 340.7);
      ctx.lineTo(327.7, 348.4);
      ctx.closePath();
      ctx.fill();
}
var led26 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(329.3, 354.2);
      ctx.lineTo(328.1, 350.0);
      ctx.lineTo(352.4, 343.5);
      ctx.lineTo(353.5, 347.7);
      ctx.lineTo(329.3, 354.2);
      ctx.closePath();
      ctx.fill();
}
var led27 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(330.6, 360.0);
      ctx.lineTo(329.6, 355.8);
      ctx.lineTo(354.2, 350.6);
      ctx.lineTo(355.1, 354.8);
      ctx.lineTo(330.6, 360.0);
      ctx.closePath();
      ctx.fill();
}
var led28 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(331.6, 365.9);
      ctx.lineTo(330.9, 361.7);
      ctx.lineTo(355.6, 357.7);
      ctx.lineTo(356.3, 362.0);
      ctx.lineTo(331.6, 365.9);
      ctx.closePath();
      ctx.fill();
}
var led29 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(332.2, 371.8);
      ctx.lineTo(331.7, 367.6);
      ctx.lineTo(356.7, 365.0);
      ctx.lineTo(357.1, 369.2);
      ctx.lineTo(332.2, 371.8);
      ctx.closePath();
      ctx.fill();
}
var led30 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(332.6, 377.8);
      ctx.lineTo(332.3, 373.5);
      ctx.lineTo(357.4, 372.2);
      ctx.lineTo(357.6, 376.5);
      ctx.lineTo(332.6, 377.8);
      ctx.closePath();
      ctx.fill();
}
var led31 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(332.6, 383.8);
      ctx.lineTo(332.6, 379.5);
      ctx.lineTo(357.7, 379.5);
      ctx.lineTo(357.7, 383.8);
      ctx.lineTo(332.6, 383.8);
      ctx.closePath();
      ctx.fill();
}
var led32 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(332.4, 389.7);
      ctx.lineTo(332.5, 385.4);
      ctx.lineTo(357.6, 386.8);
      ctx.lineTo(357.4, 391.0);
      ctx.lineTo(332.4, 389.7);
      ctx.closePath();
      ctx.fill();
}
var led33 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(331.8, 395.7);
      ctx.lineTo(332.2, 391.4);
      ctx.lineTo(357.2, 394.0);
      ctx.lineTo(356.7, 398.3);
      ctx.lineTo(331.8, 395.7);
      ctx.closePath();
      ctx.fill();
}
var led34 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(330.9, 401.6);
      ctx.lineTo(331.5, 397.3);
      ctx.lineTo(356.3, 401.3);
      ctx.lineTo(355.6, 405.5);
      ctx.lineTo(330.9, 401.6);
      ctx.closePath();
      ctx.fill();
}
var led35 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(329.7, 407.4);
      ctx.lineTo(330.5, 403.2);
      ctx.lineTo(355.1, 408.5);
      ctx.lineTo(354.2, 412.6);
      ctx.lineTo(329.7, 407.4);
      ctx.closePath();
      ctx.fill();
}
var led36 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(328.2, 413.2);
      ctx.lineTo(329.3, 409.1);
      ctx.lineTo(353.5, 415.6);
      ctx.lineTo(352.4, 419.7);
      ctx.lineTo(328.2, 413.2);
      ctx.closePath();
      ctx.fill();
}
var led37 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(326.4, 418.9);
      ctx.lineTo(327.7, 414.8);
      ctx.lineTo(351.6, 422.6);
      ctx.lineTo(350.2, 426.7);
      ctx.lineTo(326.4, 418.9);
      ctx.closePath();
      ctx.fill();
}
var led38 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(324.3, 424.5);
      ctx.lineTo(325.8, 420.5);
      ctx.lineTo(349.2, 429.5);
      ctx.lineTo(347.7, 433.5);
      ctx.lineTo(324.3, 424.5);
      ctx.closePath();
      ctx.fill();
}
var led39 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(321.9, 430.0);
      ctx.lineTo(323.6, 426.0);
      ctx.lineTo(346.6, 436.3);
      ctx.lineTo(344.8, 440.2);
      ctx.lineTo(321.9, 430.0);
      ctx.closePath();
      ctx.fill();
}
var led40 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(319.3, 435.3);
      ctx.lineTo(321.1, 431.5);
      ctx.lineTo(343.6, 442.9);
      ctx.lineTo(341.6, 446.7);
      ctx.lineTo(319.3, 435.3);
      ctx.closePath();
      ctx.fill();
}
var led41 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(316.3, 440.5);
      ctx.lineTo(318.4, 436.8);
      ctx.lineTo(340.2, 449.3);
      ctx.lineTo(338.0, 453.0);
      ctx.lineTo(316.3, 440.5);
      ctx.closePath();
      ctx.fill();
}
var led42 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(313.1, 445.5);
      ctx.lineTo(315.4, 441.9);
      ctx.lineTo(336.5, 455.6);
      ctx.lineTo(334.1, 459.2);
      ctx.lineTo(313.1, 445.5);
      ctx.closePath();
      ctx.fill();
}
var led43 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(309.6, 450.4);
      ctx.lineTo(312.1, 446.9);
      ctx.lineTo(332.5, 461.7);
      ctx.lineTo(329.9, 465.1);
      ctx.lineTo(309.6, 450.4);
      ctx.closePath();
      ctx.fill();
}
var led44 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(305.9, 455.1);
      ctx.lineTo(308.6, 451.7);
      ctx.lineTo(328.1, 467.5);
      ctx.lineTo(325.4, 470.8);
      ctx.lineTo(305.9, 455.1);
      ctx.closePath();
      ctx.fill();
}
var led45 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(302.0, 459.5);
      ctx.lineTo(304.8, 456.3);
      ctx.lineTo(323.5, 473.1);
      ctx.lineTo(320.6, 476.3);
      ctx.lineTo(302.0, 459.5);
      ctx.closePath();
      ctx.fill();
}
var led46 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(297.8, 463.8);
      ctx.lineTo(300.8, 460.7);
      ctx.lineTo(318.5, 478.5);
      ctx.lineTo(315.5, 481.5);
      ctx.lineTo(297.8, 463.8);
      ctx.closePath();
      ctx.fill();
}
var led47 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(293.4, 467.8);
      ctx.lineTo(296.5, 464.9);
      ctx.lineTo(313.3, 483.6);
      ctx.lineTo(310.1, 486.4);
      ctx.lineTo(293.4, 467.8);
      ctx.closePath();
      ctx.fill();
}
var led48 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(288.8, 471.6);
      ctx.lineTo(292.1, 468.8);
      ctx.lineTo(307.9, 488.4);
      ctx.lineTo(304.5, 491.1);
      ctx.lineTo(288.8, 471.6);
      ctx.closePath();
      ctx.fill();
}
var led49 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(283.9, 475.2);
      ctx.lineTo(287.4, 472.6);
      ctx.lineTo(302.2, 492.9);
      ctx.lineTo(298.7, 495.4);
      ctx.lineTo(283.9, 475.2);
      ctx.closePath();
      ctx.fill();
}
var led50 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(279.0, 478.4);
      ctx.lineTo(282.6, 476.0);
      ctx.lineTo(296.2, 497.2);
      ctx.lineTo(292.6, 499.5);
      ctx.lineTo(279.0, 478.4);
      ctx.closePath();
      ctx.fill();
}
var led51 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(273.8, 481.5);
      ctx.lineTo(277.5, 479.3);
      ctx.lineTo(290.1, 501.1);
      ctx.lineTo(286.4, 503.2);
      ctx.lineTo(273.8, 481.5);
      ctx.closePath();
      ctx.fill();
}
var led52 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(268.5, 484.2);
      ctx.lineTo(272.4, 482.2);
      ctx.lineTo(283.7, 504.6);
      ctx.lineTo(279.9, 506.6);
      ctx.lineTo(268.5, 484.2);
      ctx.closePath();
      ctx.fill();
}
var led53 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(263.0, 486.7);
      ctx.lineTo(267.0, 484.9);
      ctx.lineTo(277.2, 507.9);
      ctx.lineTo(273.3, 509.6);
      ctx.lineTo(263.0, 486.7);
      ctx.closePath();
      ctx.fill();
}
var led54 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(257.5, 488.9);
      ctx.lineTo(261.5, 487.3);
      ctx.lineTo(270.5, 510.8);
      ctx.lineTo(266.5, 512.3);
      ctx.lineTo(257.5, 488.9);
      ctx.closePath();
      ctx.fill();
}
var led55 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(251.8, 490.8);
      ctx.lineTo(256.0, 489.4);
      ctx.lineTo(263.7, 513.3);
      ctx.lineTo(259.6, 514.6);
      ctx.lineTo(251.8, 490.8);
      ctx.closePath();
      ctx.fill();
}
var led56 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(246.1, 492.3);
      ctx.lineTo(250.3, 491.2);
      ctx.lineTo(256.8, 515.5);
      ctx.lineTo(252.6, 516.6);
      ctx.lineTo(246.1, 492.3);
      ctx.closePath();
      ctx.fill();
}
var led57 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(240.3, 493.6);
      ctx.lineTo(244.5, 492.7);
      ctx.lineTo(249.7, 517.3);
      ctx.lineTo(245.5, 518.2);
      ctx.lineTo(240.3, 493.6);
      ctx.closePath();
      ctx.fill();
}
var led58 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(234.4, 494.6);
      ctx.lineTo(238.7, 493.9);
      ctx.lineTo(242.6, 518.7);
      ctx.lineTo(238.4, 519.4);
      ctx.lineTo(234.4, 494.6);
      ctx.closePath();
      ctx.fill();
}
var led59 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(228.4, 495.3);
      ctx.lineTo(232.8, 494.8);
      ctx.lineTo(235.4, 519.8);
      ctx.lineTo(231.1, 520.3);
      ctx.lineTo(228.4, 495.3);
      ctx.closePath();
      ctx.fill();
}
var led60 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(222.5, 495.6);
      ctx.lineTo(226.8, 495.4);
      ctx.lineTo(228.1, 520.5);
      ctx.lineTo(223.9, 520.7);
      ctx.lineTo(222.5, 495.6);
      ctx.closePath();
      ctx.fill();
}
var led61 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(216.5, 495.7);
      ctx.lineTo(220.9, 495.7);
      ctx.lineTo(220.8, 520.8);
      ctx.lineTo(216.6, 520.8);
      ctx.lineTo(216.5, 495.7);
      ctx.closePath();
      ctx.fill();
}
var led62 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(210.5, 495.4);
      ctx.lineTo(214.9, 495.6);
      ctx.lineTo(213.6, 520.7);
      ctx.lineTo(209.3, 520.5);
      ctx.lineTo(210.5, 495.4);
      ctx.closePath();
      ctx.fill();
}
var led63 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(204.6, 494.8);
      ctx.lineTo(209.0, 495.3);
      ctx.lineTo(206.3, 520.3);
      ctx.lineTo(202.1, 519.8);
      ctx.lineTo(204.6, 494.8);
      ctx.closePath();
      ctx.fill();
}
var led64 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(198.7, 493.9);
      ctx.lineTo(203.0, 494.6);
      ctx.lineTo(199.1, 519.4);
      ctx.lineTo(194.8, 518.7);
      ctx.lineTo(198.7, 493.9);
      ctx.closePath();
      ctx.fill();
}
var led65 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(192.9, 492.8);
      ctx.lineTo(197.1, 493.6);
      ctx.lineTo(191.9, 518.2);
      ctx.lineTo(187.7, 517.3);
      ctx.lineTo(192.9, 492.8);
      ctx.closePath();
      ctx.fill();
}
var led66 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(187.1, 491.3);
      ctx.lineTo(191.3, 492.4);
      ctx.lineTo(184.8, 516.6);
      ctx.lineTo(180.6, 515.5);
      ctx.lineTo(187.1, 491.3);
      ctx.closePath();
      ctx.fill();
}
var led67 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(181.4, 489.5);
      ctx.lineTo(185.5, 490.8);
      ctx.lineTo(177.8, 514.7);
      ctx.lineTo(173.7, 513.4);
      ctx.lineTo(181.4, 489.5);
      ctx.closePath();
      ctx.fill();
}
var led68 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(175.8, 487.4);
      ctx.lineTo(179.9, 488.9);
      ctx.lineTo(170.9, 512.4);
      ctx.lineTo(166.9, 510.8);
      ctx.lineTo(175.8, 487.4);
      ctx.closePath();
      ctx.fill();
}
var led69 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(170.3, 485.0);
      ctx.lineTo(174.3, 486.7);
      ctx.lineTo(164.1, 509.7);
      ctx.lineTo(160.2, 507.9);
      ctx.lineTo(170.3, 485.0);
      ctx.closePath();
      ctx.fill();
}
var led70 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(165.0, 482.3);
      ctx.lineTo(168.9, 484.2);
      ctx.lineTo(157.5, 506.6);
      ctx.lineTo(153.7, 504.7);
      ctx.lineTo(165.0, 482.3);
      ctx.closePath();
      ctx.fill();
}
var led71 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(159.8, 479.4);
      ctx.lineTo(163.6, 481.5);
      ctx.lineTo(151.0, 503.3);
      ctx.lineTo(147.3, 501.1);
      ctx.lineTo(159.8, 479.4);
      ctx.closePath();
      ctx.fill();
}
var led72 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(154.8, 476.2);
      ctx.lineTo(158.4, 478.5);
      ctx.lineTo(144.7, 499.6);
      ctx.lineTo(141.2, 497.2);
      ctx.lineTo(154.8, 476.2);
      ctx.closePath();
      ctx.fill();
}
var led73 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(149.9, 472.7);
      ctx.lineTo(153.5, 475.2);
      ctx.lineTo(138.7, 495.6);
      ctx.lineTo(135.2, 493.0);
      ctx.lineTo(149.9, 472.7);
      ctx.closePath();
      ctx.fill();
}
var led74 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(145.2, 469.0);
      ctx.lineTo(148.7, 471.7);
      ctx.lineTo(132.8, 491.2);
      ctx.lineTo(129.5, 488.5);
      ctx.lineTo(145.2, 469.0);
      ctx.closePath();
      ctx.fill();
}
var led75 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(140.8, 465.0);
      ctx.lineTo(144.1, 467.9);
      ctx.lineTo(127.2, 486.6);
      ctx.lineTo(124.0, 483.7);
      ctx.lineTo(140.8, 465.0);
      ctx.closePath();
      ctx.fill();
}
var led76 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(136.5, 460.8);
      ctx.lineTo(139.6, 463.9);
      ctx.lineTo(121.8, 481.6);
      ctx.lineTo(118.8, 478.6);
      ctx.lineTo(136.5, 460.8);
      ctx.closePath();
      ctx.fill();
}
var led77 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(132.5, 456.4);
      ctx.lineTo(135.4, 459.6);
      ctx.lineTo(116.7, 476.4);
      ctx.lineTo(113.9, 473.3);
      ctx.lineTo(132.5, 456.4);
      ctx.closePath();
      ctx.fill();
}
var led78= function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(128.7, 451.8);
      ctx.lineTo(131.5, 455.2);
      ctx.lineTo(111.9, 471.0);
      ctx.lineTo(109.3, 467.6);
      ctx.lineTo(128.7, 451.8);
      ctx.closePath();
      ctx.fill();
}
var led79 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(125.1, 447.0);
      ctx.lineTo(127.7, 450.5);
      ctx.lineTo(107.4, 465.3);
      ctx.lineTo(104.9, 461.8);
      ctx.lineTo(125.1, 447.0);
      ctx.closePath();
      ctx.fill();
}
var led80 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(121.9, 442.0);
      ctx.lineTo(124.3, 445.6);
      ctx.lineTo(103.2, 459.3);
      ctx.lineTo(100.9, 455.7);
      ctx.lineTo(121.9, 442.0);
      ctx.closePath();
      ctx.fill();
}
var led81 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(118.8, 436.9);
      ctx.lineTo(121.0, 440.6);
      ctx.lineTo(99.3, 453.2);
      ctx.lineTo(97.2, 449.5);
      ctx.lineTo(118.8, 436.9);
      ctx.closePath();
      ctx.fill();
}
var led82 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(116.1, 431.6);
      ctx.lineTo(118.1, 435.4);
      ctx.lineTo(95.7, 446.8);
      ctx.lineTo(93.8, 443.0);
      ctx.lineTo(116.1, 431.6);
      ctx.closePath();
      ctx.fill();
}
var led83 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(113.6, 426.2);
      ctx.lineTo(115.4, 430.1);
      ctx.lineTo(92.5, 440.3);
      ctx.lineTo(90.7, 436.4);
      ctx.lineTo(113.6, 426.2);
      ctx.closePath();
      ctx.fill();
}
var led84 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(111.4, 420.6);
      ctx.lineTo(113.0, 424.6);
      ctx.lineTo(89.6, 433.6);
      ctx.lineTo(88.1, 429.6);
      ctx.lineTo(111.4, 420.6);
      ctx.closePath();
      ctx.fill();
}
var led85 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(109.5, 414.9);
      ctx.lineTo(110.9, 419.0);
      ctx.lineTo(87.0, 426.8);
      ctx.lineTo(85.7, 422.7);
      ctx.lineTo(109.5, 414.9);
      ctx.closePath();
      ctx.fill();
}
var led86 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(108.0, 409.2);
      ctx.lineTo(109.1, 413.3);
      ctx.lineTo(84.9, 419.9);
      ctx.lineTo(83.8, 415.7);
      ctx.lineTo(108.0, 409.2);
      ctx.closePath();
      ctx.fill();
}
var led87 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(106.7, 403.3);
      ctx.lineTo(107.6, 407.6);
      ctx.lineTo(83.0, 412.8);
      ctx.lineTo(82.2, 408.6);
      ctx.lineTo(106.7, 403.3);
      ctx.closePath();
      ctx.fill();
}
var led88 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(105.7, 397.5);
      ctx.lineTo(106.4, 401.7);
      ctx.lineTo(81.6, 405.7);
      ctx.lineTo(80.9, 401.4);
      ctx.lineTo(105.7, 397.5);
      ctx.closePath();
      ctx.fill();
}
var led89 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(105.0, 391.5);
      ctx.lineTo(105.5, 395.8);
      ctx.lineTo(80.5, 398.5);
      ctx.lineTo(80.1, 394.2);
      ctx.lineTo(105.0, 391.5);
      ctx.closePath();
      ctx.fill();
}
var led90 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(104.7, 385.6);
      ctx.lineTo(104.9, 389.9);
      ctx.lineTo(79.8, 391.2);
      ctx.lineTo(79.6, 386.9);
      ctx.lineTo(104.7, 385.6);
      ctx.closePath();
      ctx.fill();
}
var led91 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(104.6, 379.6);
      ctx.lineTo(104.6, 383.9);
      ctx.lineTo(79.5, 383.9);
      ctx.lineTo(79.5, 379.7);
      ctx.lineTo(104.6, 379.6);
      ctx.closePath();
      ctx.fill();
}
var led92 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(104.9, 373.6);
      ctx.lineTo(104.7, 377.9);
      ctx.lineTo(79.6, 376.7);
      ctx.lineTo(79.8, 372.4);
      ctx.lineTo(104.9, 373.6);
      ctx.closePath();
      ctx.fill();
}
var led93 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(105.5, 367.7);
      ctx.lineTo(105.0, 372.0);
      ctx.lineTo(80.1, 369.4);
      ctx.lineTo(80.5, 365.1);
      ctx.lineTo(105.5, 367.7);
      ctx.closePath();
      ctx.fill();
}
var led94 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(106.4, 361.8);
      ctx.lineTo(105.7, 366.1);
      ctx.lineTo(80.9, 362.2);
      ctx.lineTo(81.6, 357.9);
      ctx.lineTo(106.4, 361.8);
      ctx.closePath();
      ctx.fill();
}
var led95 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(107.5, 355.9);
      ctx.lineTo(106.6, 360.2);
      ctx.lineTo(82.1, 355.0);
      ctx.lineTo(83.0, 350.8);
      ctx.lineTo(107.5, 355.9);
      ctx.closePath();
      ctx.fill();
}
var led96 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(109.1, 350.2);
      ctx.lineTo(107.9, 354.3);
      ctx.lineTo(83.7, 347.9);
      ctx.lineTo(84.8, 343.7);
      ctx.lineTo(109.1, 350.2);
      ctx.closePath();
      ctx.fill();
}
var led97 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(110.9, 344.5);
      ctx.lineTo(109.5, 348.6);
      ctx.lineTo(85.7, 340.9);
      ctx.lineTo(87.0, 336.8);
      ctx.lineTo(110.9, 344.5);
      ctx.closePath();
      ctx.fill();
}
var led98 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(112.9, 338.9);
      ctx.lineTo(111.4, 342.9);
      ctx.lineTo(88.0, 334.0);
      ctx.lineTo(89.5, 330.0);
      ctx.lineTo(112.9, 338.9);
      ctx.closePath();
      ctx.fill();
}
var led99 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(115.3, 333.4);
      ctx.lineTo(113.6, 337.3);
      ctx.lineTo(90.7, 327.2);
      ctx.lineTo(92.4, 323.3);
      ctx.lineTo(115.3, 333.4);
      ctx.closePath();
      ctx.fill();
}
var led100 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(118.0, 328.1);
      ctx.lineTo(116.0, 331.9);
      ctx.lineTo(93.7, 320.6);
      ctx.lineTo(95.6, 316.7);
      ctx.lineTo(118.0, 328.1);
      ctx.closePath();
      ctx.fill();
}
var led101 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(120.9, 322.9);
      ctx.lineTo(118.8, 326.6);
      ctx.lineTo(97.0, 314.1);
      ctx.lineTo(99.2, 310.4);
      ctx.lineTo(120.9, 322.9);
      ctx.closePath();
      ctx.fill();
}
var led102 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(124.1, 317.8);
      ctx.lineTo(121.8, 321.4);
      ctx.lineTo(100.7, 307.9);
      ctx.lineTo(103.1, 304.3);
      ctx.lineTo(124.1, 317.8);
      ctx.closePath();
      ctx.fill();
}
var led103 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(127.6, 313.0);
      ctx.lineTo(125.1, 316.5);
      ctx.lineTo(104.8, 301.8);
      ctx.lineTo(107.3, 298.3);
      ctx.lineTo(127.6, 313.0);
      ctx.closePath();
      ctx.fill();
}
var led104 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(131.4, 308.3);
      ctx.lineTo(128.6, 311.7);
      ctx.lineTo(109.1, 295.9);
      ctx.lineTo(111.8, 292.6);
      ctx.lineTo(131.4, 308.3);
      ctx.closePath();
      ctx.fill();
}
var led105 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(135.3, 303.8);
      ctx.lineTo(132.4, 307.1);
      ctx.lineTo(113.8, 290.3);
      ctx.lineTo(116.7, 287.1);
      ctx.lineTo(135.3, 303.8);
      ctx.closePath();
      ctx.fill();
}
var led106 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(139.5, 299.6);
      ctx.lineTo(136.4, 302.7);
      ctx.lineTo(118.7, 285.0);
      ctx.lineTo(121.7, 281.9);
      ctx.lineTo(139.5, 299.6);
      ctx.closePath();
      ctx.fill();
}
var led107 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(143.9, 295.6);
      ctx.lineTo(140.7, 298.5);
      ctx.lineTo(123.9, 279.9);
      ctx.lineTo(127.1, 277.0);
      ctx.lineTo(143.9, 295.6);
      ctx.closePath();
      ctx.fill();
}
var led108 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(148.5, 291.8);
      ctx.lineTo(145.1, 294.5);
      ctx.lineTo(129.3, 275.0);
      ctx.lineTo(132.7, 272.4);
      ctx.lineTo(148.5, 291.8);
      ctx.closePath();
      ctx.fill();
}
var led109 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(153.3, 288.2);
      ctx.lineTo(149.8, 290.8);
      ctx.lineTo(135.1, 270.5);
      ctx.lineTo(138.5, 268.0);
      ctx.lineTo(153.3, 288.2);
      ctx.closePath();
      ctx.fill();
}
var led110 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(158.3, 284.9);
      ctx.lineTo(154.6, 287.3);
      ctx.lineTo(141.0, 266.3);
      ctx.lineTo(144.6, 264.0);
      ctx.lineTo(158.3, 284.9);
      ctx.closePath();
      ctx.fill();
}
var led111 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(163.4, 281.9);
      ctx.lineTo(159.7, 284.1);
      ctx.lineTo(147.1, 262.4);
      ctx.lineTo(150.9, 260.2);
      ctx.lineTo(163.4, 281.9);
      ctx.closePath();
      ctx.fill();
}
var led112 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(168.7, 279.2);
      ctx.lineTo(164.8, 281.1);
      ctx.lineTo(153.5, 258.8);
      ctx.lineTo(157.3, 256.9);
      ctx.lineTo(168.7, 279.2);
      ctx.closePath();
      ctx.fill();
}
var led113 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(174.2, 276.7);
      ctx.lineTo(170.2, 278.5);
      ctx.lineTo(160.0, 255.6);
      ctx.lineTo(163.9, 253.8);
      ctx.lineTo(174.2, 276.7);
      ctx.closePath();
      ctx.fill();
}
var led114 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(179.7, 274.5);
      ctx.lineTo(175.7, 276.1);
      ctx.lineTo(166.7, 252.7);
      ctx.lineTo(170.7, 251.1);
      ctx.lineTo(179.7, 274.5);
      ctx.closePath();
      ctx.fill();
}
var led115 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(185.4, 272.6);
      ctx.lineTo(181.3, 274.0);
      ctx.lineTo(173.5, 250.1);
      ctx.lineTo(177.6, 248.8);
      ctx.lineTo(185.4, 272.6);
      ctx.closePath();
      ctx.fill();
}
var led116 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(191.1, 271.0);
      ctx.lineTo(186.9, 272.2);
      ctx.lineTo(180.5, 248.0);
      ctx.lineTo(184.6, 246.8);
      ctx.lineTo(191.1, 271.0);
      ctx.closePath();
      ctx.fill();
}
var led117 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(197.0, 269.8);
      ctx.lineTo(192.7, 270.6);
      ctx.lineTo(187.5, 246.2);
      ctx.lineTo(191.7, 245.2);
      ctx.lineTo(197.0, 269.8);
      ctx.closePath();
      ctx.fill();
}
var led118 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(202.9, 268.8);
      ctx.lineTo(198.6, 269.4);
      ctx.lineTo(194.6, 244.7);
      ctx.lineTo(198.9, 244.0);
      ctx.lineTo(202.9, 268.8);
      ctx.closePath();
      ctx.fill();
}
var led119 = function(ctx){
      // lMano/Groupe/Groupe/Trac
      ctx.beginPath();
      ctx.moveTo(208.8, 268.1);
      ctx.lineTo(204.5, 268.5);
      ctx.lineTo(201.8, 243.6);
      ctx.lineTo(206.1, 243.2);
      ctx.lineTo(208.8, 268.1);
      ctx.closePath();
      ctx.fill();
}
var led120 = function(ctx){
      // lMano/Groupe/Groupe/Trac //last
      ctx.beginPath();
      ctx.moveTo(214.7, 267.8);
      ctx.lineTo(210.4, 268.0);
      ctx.lineTo(209.1, 242.9);
      ctx.lineTo(213.4, 242.7);
      ctx.lineTo(214.7, 267.8);
      ctx.closePath();
      ctx.fill();
    }
    
    
    var leftLedArray = [
      led1	,
led2	,
led3	,
led4	,
led5	,
led6	,
led7	,
led8	,
led9	,
led10	,
led11	,
led12	,
led13	,
led14	,
led15	,
led16	,
led17	,
led18	,
led19	,
led20	,
led21	,
led22	,
led23	,
led24	,
led25	,
led26	,
led27	,
led28	,
led29	,
led30	,
led31	,
led32	,
led33	,
led34	,
led35	,
led36	,
led37	,
led38	,
led39	,
led40	,
led41	,
led42	,
led43	,
led44	,
led45	,
led46	,
led47	,
led48	,
led49	,
led50	,
led51	,
led52	,
led53	,
led54	,
led55	,
led56	,
led57	,
led58	,
led59	,
led60	,
led61	,
led62	,
led63	,
led64	,
led65	,
led66	,
led67	,
led68	,
led69	,
led70	,
led71	,
led72	,
led73	,
led74	,
led75	,
led76	,
led77	,
led78	,
led79	,
led80	,
led81	,
led82	,
led83	,
led84	,
led85	,
led86	,
led87	,
led88	,
led89	,
led90	,
led91	,
led92	,
led93	,
led94	,
led95	,
led96	,
led97	,
led98	,
led99	,
led100	,
led101	,
led102	,
led103	,
led104	,
led105	,
led106	,
led107	,
led108	,
led109	,
led110	,
led111	,
led112	,
led113	,
led114	,
led115	,
led116	,
led117	,
led118	,
led119	,
led120
  
        
    ];